import logo from './logo.svg';
import './App.css';
import './jss.js';
import react, { Component } from 'react';
class App extends Component{
render(){
  return(
    <div>
      <form onClick="return false">
        <div id="c1">
         <h1>Sign Up Form</h1>
         <div>
           <h2>Username</h2>
           <input type="text" id="name"></input><br></br>
           <p><small id="username_errorMsg"></small></p>
           </div> 
          <div>
            <h2>Email</h2>
            <input type="email" id="email"></input>
              <p><small id="email_errorMsg"></small></p>
          </div> 
          <div>
            <h2>password</h2>
            <input type="password" id="pass"></input>
              <p><small id="password_errorMsg"></small></p>
          </div> 
           <button type="submit" id="submit">Submit</button>
        </div>
      </form>
      <br></br><br></br>
    </div>
  );
}
}

export default App;
