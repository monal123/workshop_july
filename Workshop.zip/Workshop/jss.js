document.getElementById('submit').addEventListener('click',function(){
    var user= document.getElementById('name').value;
    var password=document.getElementById('pass').value;
    var email=document.getElementById('email').value;
    document.getElementById('username_errorMsg').innerHTML='';
    document.getElementById('password_errorMsg').innerHTML='';
    document.getElementById('email_errorMsg').innerHTML='';
    
    var emailRegex= new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    if(user == ''){
        document.getElementById('username_errorMsg').innerHTML='Username Required';
        document.getElementById('username_errorMsg').style.color="red";
    }
    else if(email == ''){
        document.getElementById('email_errorMsg').innerHTML='Email Required';
        document.getElementById('email_errorMsg').style.color="red";
    }
    else if(!email.match(emailRegex)){
        document.getElementById(email_errorMsg).innerHTML='Email format wrong';
        document.getElementById(email_errorMsg).style.color="red";

    }
    else if(password==''){
        document.getElementById('password_errorMsg').innerHTML='Password required';
        document.getElementById('password_errorMsg').style.color="red";
    }
    else{
        alert("Successfully Submit");
    }
})